<html style="font-size: 50px;" translate="no">

<head>
    <meta charset="utf-8">
    <title>Assets</title>
    <meta http-equiv="pragma" content="no-cache">
    <meta http-equiv="cache-control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="expires" content="0">
    <meta name="viewport"
        content="width=device-width,initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no,viewport-fit=cover">
    <link rel="icon" href="/logo.png">
    <meta name="google" content="notranslate">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="full-screen" content="true">
    <meta name="x5-fullscreen" content="true">
    <meta name="360-fullscreen" content="true">
    <meta name="renderer" content="webkit">
    <meta name="robots" content="noindex, nofollow">
    <style type="text/css">
        .page-loading-con {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 30px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .page-loading {
            width: 1.5em;
            height: 1.5em;
            border-radius: 50%;
            display: inline-block;
            vertical-align: middle;
            position: relative;
        }

        .loader-outter,
        .loader-inner {
            position: absolute;
            border: 0.1em solid #0b53b4;
            border-radius: 50%;
        }

        .loader-outter {
            border-left-color: transparent;
            border-bottom: 0;
            width: 100%;
            height: 100%;
            -webkit-animation: loader-outter 1s cubic-bezier(0.42, 0.61, 0.58, 0.41) infinite;
            animation: loader-outter 1s cubic-bezier(0.42, 0.61, 0.58, 0.41) infinite;
        }

        .loader-inner {
            width: 1em;
            height: 1em;
            left: calc(50% - 0.5em);
            top: calc(50% - 0.5em);
            border-right: 0;
            border-top-color: transparent;
            -webkit-animation: loader-inner 1s cubic-bezier(0.42, 0.61, 0.58, 0.41) infinite;
            animation: loader-inner 1s cubic-bezier(0.42, 0.61, 0.58, 0.41) infinite;
        }

        @-webkit-keyframes loader-outter {
            0% {
                -webkit-transform: rotate(0deg);
                transform: rotate(0deg);
            }

            100% {
                -webkit-transform: rotate(360deg);
                transform: rotate(360deg);
            }
        }

        @keyframes loader-outter {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }

        @-webkit-keyframes loader-inner {
            0% {
                -webkit-transform: rotate(0deg);
                transform: rotate(0deg);
            }

            100% {
                -webkit-transform: rotate(-360deg);
                transform: rotate(-360deg);
            }
        }

        @keyframes loader-inner {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(-360deg);
            }
        }
    </style>
  
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html,
        body {
            width: 100%;
            text-transform: capitalize;
        }
    </style>
    <link href="{{asset('')}}js1744307594169/app.46ba12d9.1744307594169.js" rel="preload" as="script">
    <link href="{{asset('')}}js1744307594169/chunk-echarts.cc04be28.1744307594169.chunk.js" rel="preload" as="script">
    <link href="{{asset('')}}js1744307594169/chunk-vant.81420f35.1744307594169.chunk.js" rel="preload" as="script">
    <link href="{{asset('')}}js1744307594169/chunk-vendors.374f8b51.1744307594169.chunk.js" rel="preload" as="script">
    <link href="{{asset('')}}js1744307594169/chunk-vue.a3b4853b.1744307594169.chunk.js" rel="preload" as="script">
    <link href="{{asset('')}}static/css/app.c3049ff2.css" rel="preload" as="style">
    <link href="{{asset('')}}static/css/chunk-vant.d14f5539.css" rel="preload" as="style">
    <link href="{{asset('')}}static/css/chunk-vendors.794edbf9.css" rel="preload" as="style">
    <link href="{{asset('')}}static/css/chunk-vant.d14f5539.css" rel="stylesheet">
    <link href="{{asset('')}}static/css/chunk-vendors.794edbf9.css" rel="stylesheet">
    <link href="{{asset('')}}static/css/app.c3049ff2.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{asset('')}}static/css/chunk-7c54221e.86e4aaa2.css">
    <link rel="stylesheet" type="text/css" href="{{asset('')}}static/css/chunk-5576a184.9f52f39a.css">
    <script charset="utf-8" src="{{asset('')}}js1744307594169/chunk-5576a184.c49d8c14.1744307594169.chunk.js"></script>
    <link rel="stylesheet" type="text/css" href="{{asset('')}}static/css/chunk-7cbde8e8.788c4ae8.css">
    <script charset="utf-8" src="{{asset('')}}js1744307594169/chunk-7cbde8e8.43936207.1744307594169.chunk.js"></script>
    <link rel="stylesheet" type="text/css" href="{{asset('')}}static/css/chunk-4f89519c.2a0f3cea.css">
    <script charset="utf-8" src="{{asset('')}}js1744307594169/chunk-4f89519c.5238fa59.1744307594169.chunk.js"></script>
    <link rel="stylesheet" type="text/css" href="{{asset('')}}static/css/chunk-693d0a34.f05eb557.css">
    <script charset="utf-8" src="{{asset('')}}js1744307594169/chunk-693d0a34.843d936b.1744307594169.chunk.js"></script>
   
    <link rel="stylesheet" type="text/css" href="{{asset('')}}static/css/chunk-914a5cc4.205f3334.css">
</head>

<body class="mein_cn">
    <div class="page-loading-con" id="loaderInit" style="display: none;">
        <div class="page-loading">
            <div class="loader-outter"></div>
            <div class="loader-inner"></div>
        </div>
    </div>
    <div id="app" class="applang">
        <div data-v-6302a7bf="">
            <div data-v-6302a7bf="" class="van-pull-refresh">
                <div class="van-pull-refresh__track" style="transition-duration: 0ms;">
                    <div class="van-pull-refresh__head" style="height: 60px;"></div>
                    <div data-v-decd48ac="" data-v-c31487f4="" class="page">
                        <div data-v-c31487f4="" data-v-decd48ac="" class="bg bg0"></div>
                        <div data-v-decd48ac="" class="headers">
                            <div data-v-29c52665="" data-v-c31487f4="" class="head head0" data-v-decd48ac="">
                                <div data-v-29c52665="" class="container flex"><!---->
                                    <div data-v-29c52665="" class="myName">
                                        <div data-v-29c52665=""><img data-v-29c52665=""
                                                src="https://fastcoin.s3.ap-southeast-1.amazonaws.com/upload/20231025/0feefd89860da746f3a51ec0d8063854.png"
                                                alt=""></div>
                                    </div>
                                    <div data-v-29c52665="" class="name tac"></div>
                                    <div data-v-29c52665="" class="flex1"></div>
                                    <!----><!----><!----><!----><!----><!---->
                                    <div data-v-29c52665="" class="Set"><img data-v-29c52665=""
                                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAABYlAAAWJQFJUiTwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAJRSURBVHgB7ZjRUcMwDIYVjgHMBJgNOkJGYIQwATABZQLKBGQDYIJ2g7JBwgTpBkIizmFUOzWOaHjgu9M1iV35jyzZdQEmgogl2YqswS86sjVZBXNCAh7wMA2ZhWOTKM6PqIVjwVMXEVE7awLtz6AF9nm1jOWQy6/RwbHPy28vEPF148YqIVFYIxxXgX4SG+hjDvXD/TRpyC5j4u4wzEr0s5gQmZQXofuXyJh30lEV6dgEnEqB24i4RcCfCfRpImPf+APKThscyQkW5fVdBtpNwOd2xB8LfRb9u88Xwv3oPUEC2OfrIvA89MJMleCzFt9ZyoqctF6NiFsmft84DQNrEA9eIBMMT2uyOM+PXzjdKT3zE7eDfLjyrHh2WxTFCn7Gzrs2J6BHJe7vM8TtoSLQFYsRjyeLY7QiKMW1FL0dKKAlUIp5ByVOQQGK1htN8xVd8lS3ZDUooSKQIZG8yBqtqR1Qq2K3A3U49oskA60qLuFrmbFkD6DEbxWJ2jSrCOQioY9Hd8vi7kEJtRwkkfz77Yzsgq6z93SJWhUz2hXMaO7Fv8K/wKmwQD9vLMzPuXe9Cx3CLcwE7p8YNxzBV9GPT1cGjowbU/5DUReugY+E1mtooV9seQEeXTpoaWlhfGALh+G9+1pqIN8Xg5PQITuVbSji2B+i1pjPQjq8xO8nvGyRTtwW82ANZTDO2CdpjXl8ipwo7glFShQRoRyN0uVErGCMyxufN/fpTw/n8CPE4faWbKO+VWL8T6cBnq4FzMmIyPnFDQRE/h1xA9ivAo22uA8mvoZfO2FoXAAAAABJRU5ErkJggg=="
                                            alt=""></div>
                                    <div data-v-29c52665="" class="Set"><img data-v-29c52665=""
                                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAACXBIWXMAABYlAAAWJQFJUiTwAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAKISURBVHgB7VjRcdswDIV8GUAblJ2g6QYdIZ3AHsEbWJrA2cAZoZ1A7gRuJqA6gb0BCoS0AyGkREmMnY+8O9xZFAg+gyAACkAAEUuSDYnF6+FAsiMx0AdSWJIc8Xbgtdcxcmv8OFhKbgU61x5ISjF+IvkN7w9e8xuJUWt/LYri9PJEBJ/UP+DnEq4EdHGvOVRS4SBe2GuSUyRl/Fv5UuIX3Ajai+fxhdI7wgfDYkgB3Qmfkn7iaSMnQcIGuic8FaWfOwspBFuYjhPMxF2Czk8S3qqxXmRyjzATgwQpYbbgCN4EKVt8U3wSnIupeTApx+Frf9lgt8c8+jG2bYaMSOwC72NJ+thj03gCqdhp/TEEDxGjNkJuauXp4Gxvah4M5jiyy5WjCthg/Wd4TfoGXB84nFuHPJgKDHfllmSFkRbOv7N9HsxCEF3M6W1NanzRHaTHAEeTk6DuiEeXuICNJgtB7z0JixO6cu9Jq2yVORL1g3quLxeeLoGNX3QbMuLn1Gp4ncODjZjflxsl7iM6+m7S5PCgXOw5cU4wBLwX/4ohwwT/yQEYD7mYhfno8LnzRr/4gXt2cyiGMoPXuTzQevuoJilWKj5WMAKk38qY6dHrQyP0mk5M+8CUsDgiTWiDGK8avRB68pDsF34798KWIdlCOv6I30zuIaJXQxy1J7eCbky7DwkYLlVbTC9Vk3dA2bHKlpEK0WKfYLxR86bk023IRqGUKghfts/5qY3YNyQ/1BjX43ooI3hvc0it1Hrf/Y3yzYQsDefQDqDb0li7dblOFJHJBlzjuYQ80DtgwFWgUKyy1ytIAbrDwx7d4/t/v87ysWnMH3saQY4dYODawPgOtH6Mq1hvSvoP7B9eUZx1/VYAAAAASUVORK5CYII="
                                            alt=""></div><!---->
                                </div>
                            </div>
                            <div data-v-c31487f4="" data-v-decd48ac="" class="logo"><img data-v-c31487f4=""
                                    data-v-decd48ac=""
                                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAcCAYAAACQ0cTtAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAANYSURBVHgBrVa/axRBFJ6N8beSjaDYZbWxklwKtVDwIgh2uVqEmNIqsbbIpRAshDv/gmxKq1wsFG3urEQQkihiI7opRImFdxiiBs36fdlvzGSze5fDPPiYmTdv3jf75s2b9UwHiePYRzMKFIECVcA6sAZ8Bd4Dj4Fnnud9b+fLa0MSoJkE2DaAOThbyLC7gOYKMAi8AB7C7ovZqcDBODAPFE0XAvtrwD3gfNa8l7GggqYfmMAOm9IxlOMm+Ur2WzLvA2rAc9hGsj0h25fQPTJtdlYBys44AEKgyq8kqeD2S8AsMJnydQO4lEfE0FWdcQGoizDQONBXGhEFIiuoreusOX8AuAUMpIkCnZHvEFVt33QQEdvNuIR9wHVgv2s8DYw6xHX1S6YL0ddx/ayjGwKYqcbTZ/KOnNFkiKYMjED3wBJ3kAXY3tb6oknu4zfoZjDeh/4w+k970bkIVOxXmeTSMgtn5IiLQ2CpDRnPuwmHUyQGIvmcgW4Nc58YapJdBe47jklSgFHDcWaJgxyyECjDoSGhznmJrQrBMnCYZMeheKtFI8BYjtObmm/mEEa0AQFb3sOGScK5oDUnSbbXWUCln1WWJDXMjZkOYrNRG6T8Bv6Q7EfK1jf/L/TRZwfY4Do28JNky44Ry1fEw7SlypHQ7Fy2rIU/+l0lWQ8Gh+B8VUa8Cq3Ugoodp8rSmK2JKQmEeUe38WWvRPDOJEV12GymL2XKZAuLAKvFUEYUGEabbAwjr5PpAV4Dp6VsoLlMMueQI4Clq6G+Rajd122ZM+ZfcnC+uW0TmDwI3HHGTN8J+5bFiRT1InzMwaxTV4t6KQKTJTI454ynpRt1yHz3C3L8sDZOxnqmbK208z1q+ZyfxcRRjVnnmAiLji+GspJD4isSLLiInlfWmGfvbyHD5C80T0xSrjhmvJkoNuZcwCQK4s3Hk/1BOQ1M8jq3HCKuKbgFotd2oPwMow90gP6idLxzG5s3SSGO5SRwNlDUnK36JbtJrK+5Ecj6BzmF5hjwRhW7rF1HCsucSWpeZHWMhM6moI3Ucu7fdsHCIyQF+oE9JFSiTKfs7AtdUgaPt0ui3iwldrWCZoWVBS1xV1MDGeZMClacMONydy+qbZn/I52uw26QMxur3a77C43woHaQIXoXAAAAAElFTkSuQmCC"
                                    alt=""></div>
                        </div>
                        <div data-v-decd48ac="" id="scroll" class="content-container"
                            style="padding-top: 44px; padding-bottom: 60px;">
                            <div data-v-decd48ac="" id="content" class="content-scroll">
                                <div data-v-c31487f4="" data-v-decd48ac="" class="container">
                                    <div data-v-c31487f4="" data-v-decd48ac="" class="income income0">
                                        <div data-v-c31487f4="" data-v-decd48ac="" class="name">Total assets
                                            (converted)</div>
                                        <div data-v-c31487f4="" data-v-decd48ac="" class="am">13.5 USDT</div>
                                        <ul data-v-c31487f4="" data-v-decd48ac="" class="flex">
                                            <li data-v-c31487f4="" data-v-decd48ac="">
                                                <div data-v-c31487f4="" data-v-decd48ac="" class="s"> 7.5 USDT
                                                </div>
                                                <div data-v-c31487f4="" data-v-decd48ac="" class="n">Available
                                                    assets</div>
                                            </li>
                                            <li data-v-c31487f4="" data-v-decd48ac="">
                                                <div data-v-c31487f4="" data-v-decd48ac="" class="s"> 6 USDT
                                                </div>
                                                <div data-v-c31487f4="" data-v-decd48ac="" class="n">Contract
                                                </div>
                                            </li>
                                            <li data-v-c31487f4="" data-v-decd48ac="">
                                                <div data-v-c31487f4="" data-v-decd48ac="" class="s"> 0 USDT
                                                </div>
                                                <div data-v-c31487f4="" data-v-decd48ac="" class="n">Funds to be
                                                    released <i data-v-c31487f4="" data-v-decd48ac=""
                                                        class="van-icon van-icon-arrow"><!----></i></div>
                                            </li>
                                            <li data-v-c31487f4="" data-v-decd48ac="">
                                                <div data-v-c31487f4="" data-v-decd48ac="" class="s"> 0 USDT
                                                </div>
                                                <div data-v-c31487f4="" data-v-decd48ac="" class="n">Total
                                                    contract income</div>
                                            </li>
                                        </ul>
                                    </div>
                                    <ul data-v-c31487f4="" data-v-decd48ac="" class="tab">


                                   
                                        <li data-v-c31487f4="" data-v-decd48ac="">
                                        <a href="{{route('user.invest')}}">    
                                        <img data-v-c31487f4=""
                                                data-v-decd48ac=""
                                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAACXBIWXMAACxLAAAsSwGlPZapAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAp0SURBVHgB7VxNbBvHFX4zu5RE2oZVUVYtA4Xp1G7j1EDlGijQXkzfW8A9JEDRg6mLe2vlUwH7IOngoOlFVm/xJcqpBx/iAr2bvrRA0VYKoFpunCAMUliOLAo0bJMWuTOT98RlIJMz+8MdUhSiDyAozc9q9e37mzdvFuAABzjAAb69YLDPMD4+npcSLuKtV6RUH1cqm0XYQ+wrAsfHJ+aUUrOariJ+llIp5/6TJ09K0EfsGwJJ8pRi9yIMLeJnqVx++iH0ARy6QG52eRT6DCnZjyMOzeNnKZud+HxsbGLu+PHjOeghYkngGzdXC5zxBfxxVAGUcPrcZ9fP9uVJZ7PHCvj1AcQGKykFH25tbcxBDxCZwDN/Wp1SHl/u6FBq/tMbP5qDHmMUwXlqmTHIQVdgJfzMlMtf/RUsIrIKI3lXtB2MzZ6++d856DEqCCkbl1CaluhXiA2VQ0Nwd3z82AI9DLCEyAQyxkYDOvtFYmlr6+k0OojvCNE4hYRME6H4KUW9Bo6dcZyhZVu2MboTkeJ+YH+fSGyByCyXy0tEKH5OCSEvIz3FaLNVrtEQy9ls9jIkRCwncubd1SUFBlVuoU820QTUzhzaylm0lYUo4zGuvLa1tXkLukTsOHA/kEjwibwXxelgfDnfrZfuKpDeLyQSxsbGZ9B+0+ol0HF0K4ldr0Rskpifvec+Gj5+dER6mbqCoSGeTouUdB0hnG8GydS2ZI06l14txd2qd9h98envzmxDBESVRiHUpbhr60RLuSQkEmnrmcmJulCHOYMj0AW451QdR2xEIZNCF/S+GIirIMdRwfX0+Tjr6cRr4bgktojbZnziNQlLCAFQdg+562FE4opmCb8C7peVhKifp7gTIsBKMiEqiY7r3LZNXDvqvLb+5R9+8jhoTBiJqOq3NjefXoMIsJaNiUKiYuw2ft2GHkMx5DHjfhIkjUgiZXbypv6o9tBqOmuQSBRSCKg3SqX581pVDF9bR1PlrtJZJjy6fq7AQAZmZ5hSV/HrKvQYDnccZ2Tk+9977z8ndP2ttTUY19UKPbf7ewiBVQIJg0QiYUimJwNIxFSXmjfNxfhxJizxYJ1AwqHtxgx+/S1oTBIS0e78miu4h9f4Fzqn97lyJoPGE4lvvruW1fX5wXPRMHU0TAqtp/RP//nRsPdKnSVPi//gHDb9Imh8XJuIT/yqapL/DRiwxw3m/cYB97lpHtlE98jwms6xhGwXVCjzY7KF1iVQVr0ftMIUJGcObEuiUr/saAJ1gkl+IWga2UT2TL2h69vc3Cz6eUYdyNkYHaNVAn/43sMTDJdiu9tsk4hbCVp1ZYwfDpkK0hWZkzcfaOdzrox2Gz21cfVijcAd1ZVKe3M9kcQugQ7uu2+/rToCeZJCMNvCvMmZWCPQe+kFGvJBIZFU+Z9TaxO6PsbMHtmkxlYIJOnDR5oNGzcoJJqk0PO8FTDEhSY1tkKg+8ILtT8tDAKJJin0Pe1dw7QpnRpbIVA4zkSc8YNAImfMlEIz7f0gealcx3UgIUh9pRQZiIm9JpFykDo1xgisaJzDqaiprQ0SIo76tmOvSfz7+YcdKlmp7CRTjevj9pbEBHqOm4YE2EsS09ume9dvj+oyNy4khBBehidcEBKJSBL9aFz2EYk4Dmxi2301rO9hWgnE5d5Ue1tiCeQqNQQWEEMSrWGIO1oJxLV2CSIiuRfmjWGwhCgk2oTAxZ2+h5liwVx7W0/SWUnQTxIpHtS1I1HPICIGjkBCvyUxCYxOpFXMjevDj8vlsik6xyAaIyfhBO6yoek/gupygcno+7/oUv7tMHbBlH3pJdCfHY3qr7QEZrMTH6Ehvdy8CIOxsWMrtH+gSyo6jREP7aCRQLwG5urU+w6wybjpWwU9hlSGXTs1qss168roOlS4WUr7+u49kjBlSm2zlKpB8E3O7oUURYFkrK5rx72QnGFKhwDpbOBF0F4UpnTtKCZh9SkXYEDhbLtVQ1dO14jmLJxAFFPDMoblda014QVKIO5XPIc+QCn5AmKiNmy89yn934CV9jadBJZAD8rmnGxv/PnpNwM3niXr/SY64jHnvAgxcXRbdDxcv/TXsJVJheqvo4NA9KfGUl7cqs63t915hwmpIEjK/oIriNu48bMOPQB5awHstxATmDytPpg/12EDGw2RN82RUnVIoNt5gUbJcVIkVR1PQSmex6+OzZcRlX5eZzVjiCI539m67JVX7SaYxSTIhqHromlOpbJ5P/Rv+6HKiu4ClNbWZWXPnTm5QfEg7CPo1NeHYQdOn6HRPjw0lqbAGclzOwwsqXG6cfgr2CeQQm3q1Nc/DWWwf2pJ16olEINm4x4pbk/rTkvuKylMN6TJHhs30IXQH/PQEuircRH0wD3S8Xx7436RQty7fqyTPt/75vWzVJEKkXQ9RvsboMYkhdontXYjt865YwpO9x64dPvixlta6UPvO2ueqFdfgpFAX41NMV5BJ4WEVLX+2SCqsmDcG67LT3R9vvQVdH20/sVkitGkGQkkNcalyy1Tv8kWknqMeM6XMGioVb/QqS6h0ZABB7nN0kcIDKEw2FwEsxTm6RCLruPh9bPlIZkOLPTuJ8jumUp9m/9D524bgaRPSi+wWDSQwDAppBNAplOPZA8HgUQiz2T36N79U0wGqCWT82ghNEOXtBg7t/D5KDRe5sKSrrZBNm9Eyv+TNuj6/YM3y0HSR6dAIQShqyAihnM1bR6hcrj0+8jUW7p2qpJ5CQ/MyUv74LjOzdQaaybyCP6ppZypH9e9BYiAyDlizEovoBTOBAyhN2VMB13j7M3SZJ3XTkCPQFKnhNgwqWwLmHFfQvKMQTNm429tbW3aPWgT8Z0FoSS+Nbs6VEvxSe6wcbCEFnE/XVnduHPnncAQKpw8chyN3hz1olOPqK704omA0n91VwhvOuwGiMhnw86RjONMdFOcRKA0mlTqeRTimjZvx9TkA4ZRQfn5MMexG7FrJaK9AIeVUil+KeqpxxaZ6e16WgwPZXaqHXZt2JOEoRMS9VStNvxSbr+CserPHvzjWRhpLZC3bcZ6ZpvXhPxV0A6kDl0Vm/iHmBdChlXoEEuS4/Q2EP3ANcyg112EmOi6WgclcRYlcS58ZDxptAVfU4i4fNhYfNBz+KDnoQskKneKKIkt0MvB5ntNpE8cOYlClPHdSl4LievFmq8O4fRKptGIU4poaxbj2pogkINwXXcqqsT5QIehLuvS9HFgpeAuzhsydqFV0F3s5rV1fkSA0kblJztp+KgPsBWqXIrjbU2wVrHox4mzIcF2EHb2YprlE1SfxyqtKimqVfHLLXDtuvOdhxiE7QYFyZggmI8a54XB+mHDZlES+6D7l4T1Bk2pU4WkKtsO6wv8arVaqtWqi4cOZagkFiWmO0mxCAqn/ohSh8H91v/AMqxL4G6QnULjfgUlsrAHElnx1XXRlrrq0FMCdwO9dQH/3BVTjY09qCJK/l3akuglcS30jcAWmt6TSkSskYkkqZV+krYbfSewHeh0LqKKT9E6lUrokIhR327m2oaWml/K99SsRHU8VIrSb9IOcIADHOAATXwNfZc8OEzuTG8AAAAASUVORK5CYII="
                                                alt="">  Recharge</a> </li>



                                        <li data-v-c31487f4="" data-v-decd48ac=""><img data-v-c31487f4=""
                                                data-v-decd48ac=""
                                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAACXBIWXMAACxLAAAsSwGlPZapAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAApsSURBVHgB7ZzPbxvHFcff7JKiKFmwICmqbTQwXchp4rqNhAIF2ouov6DKIbmavji3RgZ6aYxAEgonDdBCcv+ByGcfogC9m760QNFUDuDKbuyga6SwXEUSaCgiJXJnpu9xl6pLzuwv7q4oRJ8LpdnRcvXd9968mXm7ACeccMIJ310YHCHDSDabLXAO0wByWAi4V6lsleEYkbqAJJphZK8wBrP46yQ1vXxcSra4s7O5AMeEVARsE63o159zOXNcLDEDCULCZTJ9c1LK96DN0rwwDPYmfpS9+hQ+eliAONnfr1iLUxUISSIWGFW4/yFmt7e3P1MdmfhwfQ4/5qOd1xsJYAG3r3/1wU9Wg/5N7AKOjY0VpTQ+wcspQASkBGtn55sLqmMXbz4oSUbnThjOZ5588ONykK4GxARZ3ejoK8s4CNyNKF4FLXZZiMaMrgOK90tIAWlkrgTtG0sMPHPmTKHREGGFQ8HEKmNGmfNGuVKpPIVjSNcCkss2GvxTCByTJAoGCwD2FyhaqKDNpPgMrXAWeoiuXHhkZGzOcVl/8TC2rWB6Utze3qIU5V5Y8YjHNy6v4Mcy9BCRLXBsbHwBY9a8f0/H4kg0iIEn71+6/vpHa7caLP+mKWTgkViApNF7EmImkoCO5fmKhzEOFnZ2tm5BzDz6zZQFlHIEZOLmPxaAsdjFI0ILODo6ijGILXn1oVSERlP0UgsCUJy/m3mcO3O6X9gDdQl9fUY+z7MiY3JuHnYS2QPBGnVD2LWskanapzLfPvnVxQO/c7viBfCUaIQS0BltuU8eJstC2G/5xTgSbWPg7Hidy1NfMxjqp0YzA33Now0wedsfGI0cBuwc9hlq0O97Nlz87ZdV0+SbOjGTFo8ILCDleU6q4jlgrOAgcdXj+KFwFjPGycKMLlJ5keEDAmd1JCZO7bYzg5mNlpBpiEcEFtA0sws+eR6K942neD/8+NG5lnAmcIgT9PVRuWePvvrx3zdydu6an3hMyhVpGAWMN0XogkBpjBP34D19D7bqJd7EHx/nJj58cMkW8uz/xbUE6Bf5+SDiPb7xo6sQAwEt0FxqTrUVOANGXXsxr/3+b2P1ffl9k5mJCkegNVzD7OCaV584xSN8BXTzvYLmcMUdbZUDBrms3UCri9ldVRyFeO736qFRFy1MO7GmPE+XqjTFQ5eFFDgq8dzv1mPboqQbONxlJ2WSPDm/NtxL4uF4/SeTGb+GZL5fj5f16ZadaMCoDA4WIAWCiieZubAv+at0bRD/NajBtb2Sh/Wt6FxXVO3Xkh5piTDi0U+mYZrshfwBxH8dWrysb1HVTnGPSXcykSBhxTtswcT7/M31WEOLUkAaPEC7eybLKusj90gj7kUVrwUD8b2335axeYhSQJzvFvV/IpXrcfae3fPiEeTKf518OE4/M82KDmMy8FqlzoV17ltR7ZaR9dFUChIkDvFaHFqh4KosomIfHARegtMJWFQ14uCh3O7LfGufggSJUzyiZYW4wn2fduBwklVuWiN9SjGD+8MWBKRjJuJsS6o7MybKqnZcGhjHuwlJELd4h+dlbAg/NtztyzJEpMMChWhWBSjhnHcsy5P7CsEHIAGSEq95blyDjGMwUblwQdO3ohp9k3LfJMVr8eepR11XN3QIyJhu40XeV7XaZiYPMZOGeET+oPtr7xAQ45/yruD2paVq59yO1X3TEo84yOx3PbVTWaDGrKWlPIHMxjbzSFM8os8w47dA0MZApk4ucbMHYiBt8QiOkzvoksCVCZjChK4kCHERqYtHUD4IXRJbdVYXF3Ak4sVFYBOW0lDGRk5rVzzanex18WhSIQRM49z4C5zCqmdhijYLlHFQXYdiNvptjIOhBewJ8YRUVja4Nd13MSOZZM19a0bro8pt2xAuzArK1qysQUjwos71guUJxuqqdsPIlBT5cGlk5JWOrV2FgOqEGc1Ynd5I8K1PaUdw8VOfHqm4rXmQqaraGWO6StiOSYYikVYnzHjaoqq1xu3wFmgYu/qj6cW8Wk577brZWEcmonJhC9RQaDjf3viLidejPBrwuQS50Xkk3QHj9AHvuJHuarxmMtFpXB0C4niqLYQ0TbPY3nbnHcaFBA+L6gRXy3aFId/FHz93m3YxJv4hTfFs266uL17uiIFeq/FCdIa3TOcJGpZpZsmqOu4CpjJF/Ljd3t4v87t1VhuCEBjSfCYZvHvYwNJ96gwXQTY1h6Z1f6OqsjU6OzXLNDQDCcySH7e3X754fpPyQThGqNzXRVPELsuqVmUao1u6h6ZVZjoCLLlxvnHqP3BMEFxuqdzX2QvXLqasqFqVAuK+723QgNvTytKx42SF+YbY0BzS7oWrVuMJpYCuG5dBTXF4eKzY3nhcrBD3rp+prC/KXjihnYl4uDFZofJOPbxR2DAMswq9Ck7dnt64pLQ+HH09ijLV7ktoBXTdWJfjlVRWSGSr9a960ZU5M+xcXXypOuZaX0l1jKrQcCFBG9K0ApIb4/RtWXdcFwvJPfpt82voNWrVpyrXJdzieQ166yN86gNt2qHXWWGRHrhRHXj0/hvbfSL/DHoEinu6h6md/0FfAymErbU+wlNAPyvESfe8a/4dUDzsBRFJPF3co2tnngXpcsXvYSHf9N9dG1vDJLqgOYXFeX1KVyddWPrXMDT2ClEXXaNCMa9fiH+TN6iO0/9lmn1rPhW4F3y+xn89kIQxDOlRWywLOPX7VHfUun6hMrAH67rFyyQwcJ47UGs81IlHoHieT9XjvLcEAQg8AcXFxCW0wjmPLr4P2rxx0zpbN2rnICHI6iTnmzqXbTE6Or6C4nkUz8vlnZ2t6xCAwAL6u3ITXxEvzT/oq2WNs4bJxiAmWsL97P6DzTt33vFMofzFaz4oORX0eeZQSyCoIbnrGng+LydXObev+l0ACfkiZw4NmOZ41OIkWkYTUu4GEc6Jec1QU/ToVuG8KZ4FAQm9huSUv7G7Pqe1sllj5vnz5xYEoCVm/qCe57m+gWa1w0sb9mRhOAjxerZWy+2Jg30Yqf58/S8v/ERrEfydDuIt3e6bjkiLcJQ74fC/5NON3sKxiLHkSB/Rd6/V9z0z6LpzuudevIi8iomWOI+WuODfM5w1xoXrKSRc0a8v3mh6sn4RItDVMnBAS2yxks2ai0kL6QpHg0QpSP+oltei63V051HY5tuEghYrlsEZrW9DTDivmspMBrU4Fxww5Gy3L8OIZSOCRmfayfdJcdqhUZoCdhkt815Yy3QzAqrnnnbfChf0BoZ+p4MXse3kuHnivE+y7UVzL4b+OacWkeE8HF7QAWw77ZSWsIKzwd/cow4s2Ms4r5eyF6O8t0ZFIi8fE4J9EtIaE8exOlmK6/01LWKf4FerVatWq94aHBygKoeCvuI1NSid+h1aHSb3O/+EmEl0M5biFAb3K2iRpSOwSPdtcPatuNxVRWq72Thal/DrruhqbOJDltHyV2lLIknhWqRbDgCt0ZNKRGITs0IVZWmK9jKpC9gODjrT6OKTNE+lmjwUYtiNm4W2rpbzId2RmllUx0OlKGmLdsIJJ5xwgsN/AYz3ibub/xaIAAAAAElFTkSuQmCC"
                                                alt="">Withdrawal </li>
                                    </ul>
                                    <div data-v-c31487f4="" data-v-decd48ac="" class="btn task_btn themeBtBg0"> Task
                                        Center </div>
                                </div>
                                <div data-v-c31487f4="" data-v-decd48ac="" class="list">
                                    <div data-v-c31487f4="" data-v-decd48ac="" class="it">
                                        <div data-v-c31487f4="" data-v-decd48ac="" class="name"><img
                                                data-v-c31487f4="" data-v-decd48ac=""
                                                src="https://fastcoin.s3.ap-southeast-1.amazonaws.com/upload/20230918/e6ab0d3d4109e0a08784508341f5d1fc.png"
                                                alt="">USDT </div>
                                        <ul data-v-c31487f4="" data-v-decd48ac="">
                                            <li data-v-c31487f4="" data-v-decd48ac="">
                                                <div data-v-c31487f4="" data-v-decd48ac="" class="n">Available
                                                </div>
                                                <div data-v-c31487f4="" data-v-decd48ac="" class="s"> 7.50
                                                </div>
                                            </li>
                                            <li data-v-c31487f4="" data-v-decd48ac="">
                                                <div data-v-c31487f4="" data-v-decd48ac="" class="n">Contract
                                                </div>
                                                <div data-v-c31487f4="" data-v-decd48ac="" class="s">6</div>
                                            </li>
                                            <li data-v-c31487f4="" data-v-decd48ac="">
                                                <div data-v-c31487f4="" data-v-decd48ac="" class="n">Redeemable
                                                </div>
                                                <div data-v-c31487f4="" data-v-decd48ac="" class="s">0</div>
                                            </li>
                                        </ul>
                                        <div data-v-c31487f4="" data-v-decd48ac="" class="total">
                                            <div data-v-c31487f4="" data-v-decd48ac="" class="n">Total</div>
                                            <div data-v-c31487f4="" data-v-decd48ac="" class="s"> 13.50 ≈ 13.50
                                                USDT </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @include('layouts.upnl.footer')
                    </div>
                </div>
            </div>
        </div>
        <div data-v-a7d12cfc="" class="global-loading default" style="display: none;">
            <div data-v-a7d12cfc="" class="global-spinner"><img data-v-a7d12cfc=""
                    src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAArCAYAAAADgWq5AAAACXBIWXMAAAsTAAALEwEAmpwYAAAF6WlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDIgNzkuMTYwOTI0LCAyMDE3LzA3LzEzLTAxOjA2OjM5ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpwaG90b3Nob3A9Imh0dHA6Ly9ucy5hZG9iZS5jb20vcGhvdG9zaG9wLzEuMC8iIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTcgKFdpbmRvd3MpIiB4bXA6Q3JlYXRlRGF0ZT0iMjAyMi0wNC0xMlQxNTo0MTowNiswODowMCIgeG1wOk1vZGlmeURhdGU9IjIwMjItMDQtMTJUMTU6NDM6MTQrMDg6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMjItMDQtMTJUMTU6NDM6MTQrMDg6MDAiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NWU0ZGQwNmEtMWExNS1kYjRmLTkyZmQtZjIzNTAwNzJkMGNmIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjlGMTI0NjE1NTQzQzExRThCQzhCQzEyQjVDOUMzOEJGIiB4bXBNTTpPcmlnaW5hbERvY3VtZW50SUQ9InhtcC5kaWQ6OUYxMjQ2MTU1NDNDMTFFOEJDOEJDMTJCNUM5QzM4QkYiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiBwaG90b3Nob3A6SUNDUHJvZmlsZT0ic1JHQiBJRUM2MTk2Ni0yLjEiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo5RjEyNDYxMjU0M0MxMUU4QkM4QkMxMkI1QzlDMzhCRiIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo5RjEyNDYxMzU0M0MxMUU4QkM4QkMxMkI1QzlDMzhCRiIvPiA8eG1wTU06SGlzdG9yeT4gPHJkZjpTZXE+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJzYXZlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1ZTRkZDA2YS0xYTE1LWRiNGYtOTJmZC1mMjM1MDA3MmQwY2YiIHN0RXZ0OndoZW49IjIwMjItMDQtMTJUMTU6NDM6MTQrMDg6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCBDQyAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPC9yZGY6U2VxPiA8L3htcE1NOkhpc3Rvcnk+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+hddYGwAABHhJREFUWIXN2XuoFVUUx/HPXG9WmmIPJQtNwQwqe5paEI1pCBZCRvVXDwlKCsLpIURgIZZG1KEXRVJJWPRnIv3TAw/0UCsrUlBLLQ1T01Ip6eZr+mPPOHOP56jXcz3XHxzu3nv2nv29a/bstdaeyJIXdYOG4bLs77k4AzvQFyvxKw7gJ/xZHpjGSZcmam8Csg/uxU0Yi8HHMGYz1uAtfIh/uzrp8QBPwFO4HgfR1oWx52e/CViX3ef9rkwedWFJXIQncE+da7uwHcuwF1uQClbvi1G4tMF9V+GuNE5+6C7gUzANT2Joqb0Dm/A6XsO+I9yjD/7DaMzArTi1ps/iNE6mNAvcjqfxKE4rtS/BXHxytAnqqBcuwHQ8XnNtP0amcfJLo8FHWn/98QIeK8Fuw3W48ThhCbvFBsxEhMWla+3YEFUrfbsKfDpewcOKR/e5sBssPU7QusqWwTTBurlWN+rfCHg67i7V3xasurFZwHpK42QBxmFP1jQkqlbW1utbD3g0ygt7Fe7T2QLdrjROVmBSqWlkVK28WtuvHvB7pfImXNvNbA2VxsmXeKnU9FBUrVxT7lMLHGNkVt6JO/DPiQKspzROZuC3UtM7UbVyiLMMPBDzSvWFWHFC6RprrLCbwCU4ZOUy8G24OivvxCwneN02UhonWwSD5Xo3L5SBpypii/mCu+1JzRHcOwyPqpVhFMD9MSYr78OnLUWrozRO1gk7FCE8mEwBPE7hzVbiu5bSNdabpfKkqFqJcuCr0Dsrr1ETZPegPiiVJ6dxkubAQwW/TohTTxa1K4x3IKpWLmwToqfhWWMqpDEnhdI42SrENYSYpqNN2O+uyBojfN16tPqKqpV2fJNVD+LK3MJbS/0GtRqskdI42Y+zsmob/moTlkHuVQ7qHKifDCpnJtvbBMg8XmjD2S1HaqCoWhmgCDl3o1e+S3xf6tey6OwY1K4IxrZhcw68rNRpjJNHA4WsG7ancbI7B/5CcagxCv1aTVarLKS8OaumAuMh17xFsVb64YaW0tVXO27PyvuxiAL4oJC35Xq+dVwNdbEiDv5btmzL4eXcUnmEwpn0lGYpwoVFaZykdAbeJZziEB7HG0JY13JF1crlyE+BdmQsODynm60ImkcIS6WliqqVQXhO8MCEg5Yf8+u1wFvxANbjfoUHbImiaqU3XsbErGkf5qRx0pH3qXfcOj/79YSeFXaG3JAz0zjZUO7QzIF2tymLyp7BI4oXbYVg7U7qceCoWhmKBRhfal6NKWmcHPYOdeX0/EQoxkc6wy7FxDROfq83oKcsfIvw+MfXtC8VLLuj0cBmgXsLb/RIfCVkK72FrXGfELjsEXLGFHcK580DdI5zd2F2GieVo03YLPCDwqF3nmr1Ek6N1grfN7Zn/8xenNPgHsuFbxw/H8uEzQLvVLwH+UZ/pnDOQfg0UKsD2biPMS+Nk5VdmbBZ4IVCVjtVyAXPE2LYsjqEtGs9vhWCrM8cp1NqFviA4OdzXz9ESLcGC+Abhe9yy4Vk8o8m5/M/9rYMi48jzWIAAAAASUVORK5CYII="
                    alt=""></div>
        </div>
        <div data-v-b68a32e2="" class="page-loading-con" style="display: none;">
            <div data-v-b68a32e2="" class="page-loading">
                <div data-v-b68a32e2="" class="loader-outter"></div>
                <div data-v-b68a32e2="" class="loader-inner"></div>
            </div>
            <p data-v-b68a32e2="">Loading...</p>
        </div><!---->
    </div>
  
</body>

</html>
